package com.example.back_AutoYa.Entities.Enums;

public enum FuelType {
    GASOLINE,
    DIESEL,
    ELECTRIC,
    HYBRID,
    OTHER
}