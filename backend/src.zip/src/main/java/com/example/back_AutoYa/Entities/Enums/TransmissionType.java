package com.example.back_AutoYa.Entities.Enums;

public enum TransmissionType {
    AUTOMATIC,
    MANUAL
}