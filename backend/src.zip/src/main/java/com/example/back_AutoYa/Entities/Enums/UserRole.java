package com.example.back_AutoYa.Entities.Enums;

public enum UserRole {
    ADMIN,
    CLIENT
}