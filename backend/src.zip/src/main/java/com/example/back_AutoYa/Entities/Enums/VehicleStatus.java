package com.example.back_AutoYa.Entities.Enums;

public enum VehicleStatus {
    AVAILABLE,
    RENTED,
    MAINTENANCE,
    UNAVAILABLE
}