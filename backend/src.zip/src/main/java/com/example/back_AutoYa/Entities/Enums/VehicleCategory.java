package com.example.back_AutoYa.Entities.Enums;

public enum VehicleCategory {
    SEDAN,
    SUV,
    PICKUP,
    VAN,
    COUPE,
    CONVERTIBLE,
    HATCHBACK,
    OTHER
}