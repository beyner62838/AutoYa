package com.example.back_AutoYa.Entities.Enums;

public enum PaymentMethod {
    CREDIT_CARD,
    DEBIT_CARD,
    CASH,
    TRANSFER,
    OTHER
}