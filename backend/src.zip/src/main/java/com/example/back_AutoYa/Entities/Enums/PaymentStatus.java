package com.example.back_AutoYa.Entities.Enums;

public enum PaymentStatus {
    PENDING,
    COMPLETED,
    FAILED,
    CANCELLED
}