package com.example.back_AutoYa.Entities.Enums;

public enum NotificationType {
    RESERVATION,
    PAYMENT,
    PROMOTION,
    OTHER
}