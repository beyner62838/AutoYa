package com.example.back_AutoYa.service;

import com.example.back_AutoYa.Entities.TraceLog;
import com.example.back_AutoYa.repository.TraceLogRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TraceLogService {

    private final TraceLogRepository traceLogRepository;

    public TraceLogService(TraceLogRepository traceLogRepository) {
        this.traceLogRepository = traceLogRepository;
    }

    /**
     * Guarda una traza en la base de datos de forma segura.
     * Incluye control de errores y confirmación de persistencia.
     */
    @Transactional
    public TraceLog save(TraceLog log) {
        try {
            TraceLog saved = traceLogRepository.save(log);
            System.out.println("💾 TRACE INSERTADO EN BD: " 
                    + saved.getAction() 
                    + " | ID generado: " + saved.getId());
            return saved;
        } catch (Exception e) {
            System.err.println("❌ ERROR AL INSERTAR TRACE EN BD: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
}
