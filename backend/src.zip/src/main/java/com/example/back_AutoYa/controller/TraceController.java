package com.example.back_AutoYa.controller;

import com.example.back_AutoYa.Entities.TraceLog;
import com.example.back_AutoYa.repository.TraceLogRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controlador para consultar los registros de trazabilidad.
 * Acceso exclusivo para usuarios con rol ADMIN.
 */
@RestController
@RequestMapping("/api/trace")
public class TraceController {

    private final TraceLogRepository traceLogRepository;

    public TraceController(TraceLogRepository traceLogRepository) {
        this.traceLogRepository = traceLogRepository;
    }

    /**
     * Obtiene todos los registros de trazabilidad, ordenados de más reciente a más antiguo.
     * Accesible solo para el rol ADMIN.
     */
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public List<TraceLog> getAllTraces() {
        return traceLogRepository.findAll()
                .stream()
                .sorted((a, b) -> b.getId().compareTo(a.getId()))
                .toList();
    }

    /**
     * Permite filtrar los registros por usuario (email/username).
     * Ejemplo: /api/trace/user?username=cliente@mail.com
     */
    @GetMapping("/user")
    @PreAuthorize("hasRole('ADMIN')")
    public List<TraceLog> getTracesByUsername(@RequestParam String username) {
        return traceLogRepository.findAll()
                .stream()
                .filter(t -> username.equalsIgnoreCase(t.getUsername()))
                .sorted((a, b) -> b.getId().compareTo(a.getId()))
                .toList();
    }
}
