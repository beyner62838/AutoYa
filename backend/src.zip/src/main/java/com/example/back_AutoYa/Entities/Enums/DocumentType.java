package com.example.back_AutoYa.Entities.Enums;

public enum DocumentType {
    ID,
    PASSPORT,
    DRIVER_LICENSE,
    OTHER
}