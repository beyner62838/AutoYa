package com.example.back_AutoYa.Trace;

import com.example.back_AutoYa.Entities.TraceLog;
import com.example.back_AutoYa.service.TraceLogService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Optional;

/**
 * Filtro de trazabilidad que intercepta las peticiones a /api/reservations, /api/payment y /api/cars.
 * Registra información sobre el usuario, método HTTP, payload y tiempos de respuesta.
 */
public class BookingPaymentTraceFilter extends OncePerRequestFilter {

    private final TraceLogService traceLogService;
    private final ObjectMapper mapper = new ObjectMapper();

    public BookingPaymentTraceFilter(TraceLogService traceLogService) {
        this.traceLogService = traceLogService;
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getRequestURI();
        // Solo filtra reservas, pagos y autos
        return !(path.startsWith("/api/reservations")
                || path.startsWith("/api/payment")
                || path.startsWith("/api/cars"));
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain) throws ServletException, IOException {

        String contentType = Optional.ofNullable(request.getContentType()).orElse("");
        boolean isMultipart = contentType.contains("multipart/form-data");

        long start = System.currentTimeMillis();

        // ✅ Solo crear wrapper si no es multipart
        RequestBodyCachingWrapper wrapped = !isMultipart ? new RequestBodyCachingWrapper(request) : null;

        // Continuar el flujo con el wrapper (si aplica)
        chain.doFilter(wrapped != null ? wrapped : request, response);

        long duration = System.currentTimeMillis() - start;

        TraceLog log = new TraceLog();
        log.setTimeUtc(OffsetDateTime.now(ZoneOffset.UTC));
        log.setHttpMethod(request.getMethod());
        log.setPath(request.getRequestURI());
        log.setHttpStatus(response.getStatus());
        log.setDurationMs(duration);
        log.setClientIp(request.getRemoteAddr());
        log.setUserAgent(Optional.ofNullable(request.getHeader("User-Agent")).orElse(""));
        log.setUsername(Optional.ofNullable(request.getUserPrincipal())
                .map(p -> p.getName())
                .orElse("anonymous"));

        // ✅ Capturar cuerpo o parámetros según el tipo
        if (wrapped != null) {
            byte[] body = wrapped.getCached();
            if (body.length > 0) {
                try {
                    JsonNode root = mapper.readTree(body);
                    if (root.has("reservationId")) log.setReservationId(root.get("reservationId").asText());
                    if (root.has("paymentId")) log.setPaymentId(root.get("paymentId").asText());
                    if (root.has("amount")) log.setAmount(root.get("amount").asText());
                    if (root.has("status")) log.setPaymentStatus(root.get("status").asText());

                    String preview = new String(body, 0, Math.min(body.length, 2048), StandardCharsets.UTF_8);
                    log.setPayloadPreview(preview);
                    log.setPayloadHash(sha256Hex(body));
                } catch (Exception e) {
                    log.setPayloadPreview(new String(body, StandardCharsets.UTF_8));
                    log.setPayloadHash(sha256Hex(body));
                }
            } else if (request.getQueryString() != null) {
                log.setPayloadPreview(request.getQueryString());
            }
        } else if (isMultipart) {
            log.setPayloadPreview("[multipart/form-data]");
        }

        // ✅ Determinar acción según la URL
        String uri = request.getRequestURI().toLowerCase();
        if (uri.contains("/cancel")) log.setAction(TraceAction.RESERVATION_CANCELLED);
        else if (uri.contains("/hold")) log.setAction(TraceAction.RESERVATION_HELD);
        else if (uri.contains("/intent")) log.setAction(TraceAction.PAYMENT_INTENT_CREATED);
        else if (uri.contains("/capture")) log.setAction(TraceAction.PAYMENT_CAPTURED);
        else if (uri.contains("/confirm")) log.setAction(TraceAction.PAYMENT_CONFIRMED);
        else if (uri.contains("/payment")) log.setAction(TraceAction.PAYMENT_FAILED);
        else if (uri.contains("/cars")) log.setAction(TraceAction.CAR_CREATED);
        else log.setAction(TraceAction.RESERVATION_CREATED);

        // ✅ Guardar después del commit (para evitar perder trazas)
        if (TransactionSynchronizationManager.isActualTransactionActive()) {
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override
                public void afterCommit() {
                    traceLogService.save(log);
                    System.out.println("✅ TRACE GUARDADO POST-COMMIT: " + log.getAction() + " | " + log.getUsername());
                }
            });
        } else {
            traceLogService.save(log);
            System.out.println("✅ TRACE GUARDADO: " + log.getAction() + " | " + log.getUsername());
        }
    }

    private String sha256Hex(byte[] data) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(data);
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }
}
